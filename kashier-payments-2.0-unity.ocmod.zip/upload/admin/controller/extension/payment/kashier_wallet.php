<?php
if (!trait_exists('KashierController', false)) {
    include_once 'Kashier/KashierController.php';
}

class ControllerExtensionPaymentKashierWallet extends Controller
{
    /**
     * @var array
     */
    private $error = [];

    use KashierController;

    /**
     * Gateway name for humans
     * @var string
     */
    protected $gateway = 'Wallet';
    /**
     * Gateway name for system
     * @var string
     */
    protected $gateway_file = 'kashier_wallet';
    /**
     * Gateway fields
     * @var array
     */
    protected $fields = [
        'payment_kashier_wallet_mid',
        'payment_kashier_wallet_test',
        'payment_kashier_wallet_testapikey',
        'payment_kashier_wallet_liveapikey',
        'payment_kashier_wallet_debug',
        'payment_kashier_wallet_failed_status_id',
        'payment_kashier_wallet_pending_status_id',
        'payment_kashier_wallet_refunded_status_id',
        'payment_kashier_wallet_processed_status_id',
        'payment_kashier_wallet_geo_zone_id',
        'payment_kashier_wallet_status',
        'payment_kashier_wallet_sort_order'
    ];
}