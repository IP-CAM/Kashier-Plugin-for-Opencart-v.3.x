<?php
if (!trait_exists('KashierController', false)) {
    include_once 'Kashier/KashierController.php';
}

class ControllerExtensionPaymentKashierInstallment extends Controller
{
    /**
     * @var array
     */
    private $error = [];

    use KashierController;

    /**
     * Gateway name for humans
     * @var string
     */
    protected $gateway = 'Bank Installment';
    /**
     * Gateway name for system
     * @var string
     */
    protected $gateway_file = 'kashier_installment';
    /**
     * Gateway fields
     * @var array
     */
    protected $fields = [
        'payment_kashier_installment_mid',
        'payment_kashier_installment_test',
        'payment_kashier_installment_testapikey',
        'payment_kashier_installment_liveapikey',
        'payment_kashier_installment_debug',
        'payment_kashier_installment_failed_status_id',
        'payment_kashier_installment_pending_status_id',
        'payment_kashier_installment_refunded_status_id',
        'payment_kashier_installment_processed_status_id',
        'payment_kashier_installment_geo_zone_id',
        'payment_kashier_installment_status',
        'payment_kashier_installment_sort_order'
    ];
}