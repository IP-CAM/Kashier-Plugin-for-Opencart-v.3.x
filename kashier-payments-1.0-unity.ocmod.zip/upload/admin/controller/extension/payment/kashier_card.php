<?php
if (!trait_exists('KashierController', false)) {
    include_once 'Kashier/KashierController.php';
}

class ControllerExtensionPaymentKashierCard extends Controller
{
    /**
     * @var array
     */
    private $error = [];

    use KashierController;

    /**
     * Gateway name for humans
     * @var string
     */
    protected $gateway = 'Card';
    /**
     * Gateway name for system
     * @var string
     */
    protected $gateway_file = 'kashier_card';
    /**
     * Gateway fields
     * @var array
     */
    protected $fields = [
        'payment_kashier_card_mid',
        'payment_kashier_card_test',
        'payment_kashier_card_testapikey',
        'payment_kashier_card_liveapikey',
        'payment_kashier_card_debug',
        'payment_kashier_card_failed_status_id',
        'payment_kashier_card_pending_status_id',
        'payment_kashier_card_refunded_status_id',
        'payment_kashier_card_processed_status_id',
        'payment_kashier_card_geo_zone_id',
        'payment_kashier_card_status',
        'payment_kashier_card_sort_order'
    ];
}