<?php
// Heading
$_['heading_title'] = 'Kashier Payments Getaway';

// Text
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified Kashier account details!';
$_['text_edit'] = 'Edit Kashier Payments Getaway';
$_['text_kashier_getaway'] = '<a target="_BLANK" href="https://www.kashier.io/"><img src="view/image/payment/kashier.png" alt="Kashier Payments Getaway" title="Kashier Payments Getaway" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_authorization'] = 'Authorization';
$_['text_sale'] = 'Sale';

// Entry
$_['entry_mid'] = 'MID';
$_['entry_test'] = 'Test Mode';
$_['entry_testapikey'] = 'Test Api Key';
$_['entry_liveapikey'] = 'Live Api Key';
$_['entry_debug'] = 'Debug Mode';
$_['entry_failed_status'] = 'Order Failed Status';
$_['entry_pending_status'] = 'Order Pending Status';
$_['entry_processed_status'] = 'Order Successful Status';
$_['entry_status'] = 'Status';
$_['entry_sort_order'] = 'Sort Order';

// Tab
$_['tab_general'] = 'General';

// Help
$_['help_test'] = 'Use the live or testing (sandbox) gateway server to process transactions?';
$_['help_debug'] = 'Logs additional information to the system log';
$_['help_total'] = 'The checkout total the order must reach before this payment method becomes active';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify payment Kashier Payments Getaway!';
$_['error_mid'] = 'MID required!';