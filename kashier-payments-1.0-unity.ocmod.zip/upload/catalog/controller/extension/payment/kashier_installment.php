<?php
class ControllerExtensionPaymentKashierInstallment extends Controller
{
    public function index()
    {
        $this->load->language('extension/payment/kashier_installment');
        $this->load->model('extension/payment/kashier_installment');
        $data['text_testmode'] = $this->language->get('text_testmode');
        $data['testmode'] = $this->config->get('payment_kashier_installment_test');
        if ($this->config->get('payment_kashier_installment_test')) {
            $data['mode'] = 'test';
            $secret = $this->config->get('payment_kashier_installment_testapikey');
        } else {
            $data['mode'] = 'live';
            $secret= $this->config->get('payment_kashier_installment_liveapikey');
        }
        $this->load->model('checkout/order');
        $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
        if ($order_info) {

            $metaData = array(
                'Customer Order Id' => $this->session->data['order_id'],
                'Customer Telephone' => $order_info['telephone'],
                'Customer Email' => $order_info['email'],
                'Custome Name' => $order_info['payment_firstname'] . ' ' . $order_info['payment_lastname'],
            );

            $data['item_name'] = html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8');
            
            $total = $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);

            $data['currency_code'] = $order_info['currency_code'];
            $data['metaData']= json_encode($metaData);
            $data['address1'] = $order_info['payment_address_1'];
            $data['address2'] = $order_info['payment_address_2'];
            $data['city'] = $order_info['payment_city'];
            $data['zip'] = $order_info['payment_postcode'];
            $data['country'] = $order_info['payment_iso_code_2'];
            $data['email'] = $order_info['email'];
            $data['invoice'] = $this->session->data['order_id'] . ' - ' . $order_info['payment_firstname'] . ' ' . $order_info['payment_lastname'];
            $data['lc'] = ($this->session->data['language'] === 'ar') || ($this->session->data['language'] === 'eg-ar') ? 'ar' : 'en';
            $data['notify_url'] = urlencode($this->url->link('extension/payment/kashier_installment/callback', '', true));
            $data['redirectMethod'] = 'get';
            $data['mid'] = $this->config->get('payment_kashier_installment_mid');
            $data['amount'] = $total;
            $data['orderId'] = $this->session->data['order_id'] . '_' . time();
            $data['storeName'] = $this->config->get('config_name');
            $data['hash'] = $this->model_extension_payment_kashier_installment->generateKashierOrderHash(array(
                'currency' => $data['currency_code'],
                'amount' => $total,
                'mid' => $data['mid'],
                'secret' => $secret,
                'merchantOrderId' => $data['orderId'],
            ));

            $data['method'] = 'bank_installments';

            return $this->load->view('extension/payment/kashier_gateway', $data);
        }
    }
    public function callback()
    {
        $this->load->language('extension/payment/kashier_gateway');
        $this->load->model('extension/payment/kashier_installment');

        $data['payment_status'] = (!empty($this->request->get['paymentStatus']))? $this->request->get['paymentStatus'] : 'FAILURE';

        if ($this->config->get('payment_kashier_installment_test')) {
            $secret = $this->config->get('payment_kashier_installment_testapikey');
        } else {
            $secret= $this->config->get('payment_kashier_installment_liveapikey');
        }

        if (isset($this->request->get['merchantOrderId'])) {
            $order_id = substr($this->request->get['merchantOrderId'], 0, -11);
        } else {
            $order_id = 0;
        }
        $this->load->model('checkout/order');

        $order_info = $this->model_checkout_order->getOrder($order_id);
        if ($order_info) {
            
            if (isset($this->request->get['paymentStatus'])) {
                
              if($this->request->get['paymentStatus'] === 'SUCCESS') {
                  $comment = sprintf($this->language->get('text_transaction_id'), $this->request->get['transactionId']) .'<br/>'. sprintf($this->language->get('text_merchant_id'), $this->request->get['merchantOrderId']);
                  $order_status_id = $this->config->get('payment_kashier_installment_processed_status_id');
                  $this->model_extension_payment_kashier_installment->addOrderHistory($order_id, $order_status_id , $comment);
                  $this->model_extension_payment_kashier_installment->preRedirect($data);
              } else {
                 $data['payment_status'] = 'FAILURE';
                 $order_status_id = $this->config->get('payment_kashier_installment_failed_status_id');
                 $this->model_extension_payment_kashier_installment->addOrderHistory($order_id, $order_status_id );
                 $this->model_extension_payment_kashier_installment->preRedirect($data);
             } 
            }
                
         } else {
            $this->session->data['error'] = $this->language->get('error_invalid_order');
            $this->model_extension_payment_kashier_installment->preRedirect($data);  
        }
     }
    
}