<?php
// Text
$_['text_title']    = 'Pay by card (kashier)';
$_['text_testmode']    = 'Warning: The kashier gateway is in \'Test Mode\'. Your account will not be charged.';
$_['text_total']    = 'Shipping, Handling, Discounts & Taxes';

$_['text_transaction_id']           = 'Transaction ID: %s';
$_['text_merchant_id']           = 'Merchant Order ID: %s';
